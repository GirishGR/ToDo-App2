
import './App.css';
import Todo from './ToDo/Todo';


function App() {
  return (
    <div className="Container">
      <Todo/>
         
    </div>
  );
}

export default App;
